// pages/api/chat.js
// API route with robust error logging for Vercel
import axios from 'axios';

export default async function handler(req, res) {
  try {
    console.log('API /api/chat called with method', req.method);
    if (req.method !== 'POST') {
      return res.status(405).json({ error: 'Method not allowed' });
    }

    const { message, userName } = req.body ?? {};
    console.log('Payload received:', {
      messageLength: message ? message.length : 0,
      hasUserName: Boolean(userName)
    });

    const API_KEY = process.env.LLM_API_KEY;
    if (!API_KEY) {
      console.error('Missing LLM_API_KEY in environment on server!');
      return res.status(500).json({ error: 'Server misconfiguration: missing LLM_API_KEY' });
    }

    const endpoint = process.env.LLM_ENDPOINT || 'https://example-llm-endpoint.local/generate';

    const llmPayload = {
      prompt: `User (${userName || 'unknown'}): ${message}`
    };

    const llmResponse = await axios.post(endpoint, llmPayload, {
      headers: {
        Authorization: `Bearer ${API_KEY}`,
        'Content-Type': 'application/json'
      },
      timeout: 15000
    });

    return res.status(200).json({ ok: true, data: llmResponse.data });
  } catch (err) {
    console.error('API error:', err && err.stack ? err.stack : err);
    const remote = err?.response?.data ? JSON.stringify(err.response.data) : undefined;
    const message = remote || err?.message || 'Internal server error';
    return res.status(500).json({ error: String(message) });
  }
}