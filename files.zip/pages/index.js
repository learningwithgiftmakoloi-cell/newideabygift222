// pages/index.js
import { useState } from 'react';
import NameInputClient from '../components/NameInputClient';
import axios from 'axios';

export default function Home() {
  const [messages, setMessages] = useState([
    { role: 'system', text: 'Welcome to the chat' }
  ]);
  const [input, setInput] = useState('');
  const [userName, setUserName] = useState('');

  async function send() {
    if (!input) return;
    const userMsg = { role: 'user', text: input };
    setMessages((m) => [...m, userMsg]);
    setInput('');

    try {
      const resp = await axios.post('/api/chat', { message: input, userName });
      if (resp?.data?.ok) {
        const replyText = typeof resp.data.data === 'string'
          ? resp.data.data
          : JSON.stringify(resp.data.data);
        setMessages((m) => [...m, { role: 'assistant', text: replyText }]);
      } else {
        setMessages((m) => [...m, { role: 'assistant', text: 'Error from server' }]);
      }
    } catch (err) {
      console.error('Send error:', err?.response?.data || err?.message || err);
      const errText = err?.response?.data?.error || err?.message || 'Failed to reach server';
      setMessages((m) => [...m, { role: 'assistant', text: `Error: ${errText}` }]);
    }
  }

  return (
    <div style={{ padding: 20, fontFamily: 'Inter, Arial, sans-serif' }}>
      <h1>Funda Nathi IT Mastery Chatbot</h1>
      <NameInputClient onNameSet={(n) => setUserName(n)} />
      <div style={{ marginTop: 20 }}>
        <div style={{ maxHeight: 400, overflow: 'auto', marginBottom: 12, padding: 8, background: '#fffbe6', borderRadius: 8 }}>
          {messages.map((m, i) => (
            <div key={i} style={{ margin: 8 }}>
              <div style={{ fontSize: 12, color: '#666' }}>{m.role}</div>
              <div style={{ padding: 10, borderRadius: 8, background: m.role === 'user' ? '#ffffff' : '#fff1b8' }}>
                {m.text}
              </div>
            </div>
          ))}
        </div>
        <div>
          <input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Type a message..."
            style={{ padding: 8, width: '60%', marginRight: 8 }}
          />
          <button onClick={send}>Send</button>
        </div>
      </div>
    </div>
  );
}