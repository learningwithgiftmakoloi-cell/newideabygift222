// components/NameInputClient.js
import { useEffect, useState } from 'react';

export default function NameInputClient({ onNameSet }) {
  const [name, setName] = useState('');
  const [editing, setEditing] = useState(false);

  useEffect(() => {
    if (typeof window !== 'undefined') {
      try {
        const saved = localStorage.getItem('userName');
        if (saved) {
          setName(saved);
          if (onNameSet) onNameSet(saved);
        }
      } catch (e) {
        console.warn('Could not access localStorage', e);
      }
    }
  }, [onNameSet]);

  function saveName(n) {
    const final = (n || '').trim() || 'Guest';
    setName(final);
    setEditing(false);
    try {
      localStorage.setItem('userName', final);
    } catch (e) {
      console.warn('Failed to save name to localStorage', e);
    }
    if (onNameSet) onNameSet(final);
  }

  if (!name && !editing) {
    return (
      <div style={{ marginBottom: 12 }}>
        <button onClick={() => setEditing(true)}>Set your name</button>
      </div>
    );
  }

  if (editing) {
    return (
      <div style={{ marginBottom: 12 }}>
        <input
          placeholder="Enter your name"
          value={name}
          onChange={(e) => setName(e.target.value)}
          style={{ padding: 6, marginRight: 8 }}
        />
        <button onClick={() => saveName(name)}>Save</button>
        <button onClick={() => setEditing(false)} style={{ marginLeft: 6 }}>Cancel</button>
      </div>
    );
  }

  return (
    <div style={{ marginBottom: 12 }}>
      <span style={{ marginRight: 8 }}>Hi, <strong>{name}</strong></span>
      <button onClick={() => setEditing(true)}>Change</button>
    </div>
  );
}