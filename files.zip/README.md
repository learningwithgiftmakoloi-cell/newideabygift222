```markdown
# New Idea by Gift Makoloi — Chatbot

This repository contains a minimal Next.js chatbot app tailored from your original project with improvements to avoid SSR/hydration name issues and with clearer server logging for Vercel.

What is included
- Next.js app (pages/, components/)
- API route at /api/chat that logs requests and errors to server logs
- Client-only name input (avoids repeated "couldn't get your name" UI)
- README with deploy instructions

Environment variables
- LLM_API_KEY — Your LLM provider API key (required)
- LLM_ENDPOINT — Optional: endpoint to call for your LLM (defaults to a placeholder URL)

Local development
1. Install:
   npm ci
2. Create .env.local in the project root:
   LLM_API_KEY=your_real_key_here
   LLM_ENDPOINT=https://your-llm-endpoint.example/generate
3. Run:
   npm run dev
4. Open http://localhost:3000

Deploy to Vercel
1. Create a new project in Vercel and link the repository.
2. In the project settings, go to Environment Variables and add:
   - LLM_API_KEY (set for Production, Preview, Development)
   - LLM_ENDPOINT (if needed)
3. Deploy. If you encounter server errors, open the Vercel deployment and check the Functions logs — they include request payload logs and stack traces.


